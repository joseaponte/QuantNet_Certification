#include <stdio.h>

int main()
{
    int married;
    printf("Introduce value\n");
    scanf("%d",&married);
    (married!=0) ? printf("TRUE\n") : printf("FALSE\n");
    return 0;
}