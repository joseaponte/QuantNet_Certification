/*
    Jose Aponte
    Exercise 1.5.3
    The print.c file multiplies i by 2 and prints it.
*/

void print(int number){
    int result = number*2;
    printf("%d\n",result);
};