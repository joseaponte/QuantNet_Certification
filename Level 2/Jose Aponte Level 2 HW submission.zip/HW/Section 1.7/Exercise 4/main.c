/*
    Jose Aponte
    Exercise 1.7.4

*/

#include <stdio.h>
#include <string.h>

const int MAXVALUE = 10;

void DayName(){

};

int main(){
    



}