//StackException source file implements the StackException class defined in StackException Header file
#include "StackException.hpp"

StackException::StackException() {}		//Default Constructor
StackException::~StackException() {}	//Destructor