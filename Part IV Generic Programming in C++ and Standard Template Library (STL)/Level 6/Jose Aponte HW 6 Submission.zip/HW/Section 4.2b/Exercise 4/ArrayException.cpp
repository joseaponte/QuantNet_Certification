
//ArrayException source file implements the 
//ArrayException class defined in the Exceptions header file

#include "Exceptions.hpp"

ArrayException::ArrayException() {}  //Default Constructor
ArrayException::~ArrayException() {} //Destructor